# 作者: 王道 龙哥
# 2022年06月03日11时51分32秒
i=123

print(i)
print(bin(i))
print(oct(i))
print(hex(i))

# 10进制到二进制，二进制到进制
