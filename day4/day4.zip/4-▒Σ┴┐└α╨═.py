# 作者: 王道 龙哥
# 2022年06月03日11时42分04秒
i=100
f=98.5
name='xiaoming'
sex=False
print(type(i))
print(type(f))
print(type(name))
print(type(sex))