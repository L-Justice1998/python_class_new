# 作者: 王道 龙哥
# 2022年06月03日11时13分49秒
i = 100
i = 5
print(i)
i = 20


def myfunc():
    """
    我是一个多行注释
    我说明了函数的功能
    :return:
    """
    pass


myfunc()


class WorkDog():
    pass
