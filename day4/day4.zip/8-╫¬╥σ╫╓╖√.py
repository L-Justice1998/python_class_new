# 作者: 王道 龙哥
# 2022年06月03日14时46分08秒
print('123\n')
print('\tabc')
print('abc\rd')

#如何把小写字母变为大写字母
str1='a'
print(chr(ord(str1)-32))

print(ord('0'))

