# 作者: 王道 龙哥
# 2022年06月03日16时30分17秒

def wang_ba():
    # 1. 定义年龄变量
    age = 17

    # 2. 判断是否满 18 岁
    # if 语句以及缩进部分的代码是一个完整的代码块
    if age >= 18:
        print("可以进网吧嗨皮……")
    else:
        print("你还没长大，应该回家写作业！")
    # 3. 思考！- 无论条件是否满足都会执行
    print("这句代码都执行")

def jie_ri():
    holiday_name = "生日"

    if holiday_name == "情人节":
        print("买玫瑰")
        print("看电影")
    elif holiday_name == "平安夜":
        print("买苹果")
        print("吃大餐")
    elif holiday_name == "生日":
        print("买蛋糕")
    else:
        print("每天都是节日啊……")

# jie_ri()
import random
def game():
    player = int(input("请出拳 石头（1）／剪刀（2）／布（3）："))

    # 电脑 随机 出拳 - 假定电脑永远出石头
    computer = random.randint(1,3)

    # 比较胜负
    # 如果条件判断的内容太长，可以在最外侧的条件增加一对大括号
    # 再在每一个条件之间，使用回车，PyCharm 可以自动增加 8 个空格
    if ((player == 1 and computer == 2) or
            (player == 2 and computer == 3) or
            (player == 3 and computer == 1)):

        print("噢耶！！！电脑弱爆了！！！")
    elif player == computer:
        print("心有灵犀，再来一盘！")
    else:
        print("不行，我要和你决战到天亮！")

game()