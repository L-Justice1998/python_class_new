# 作者: 王道 龙哥
# 2022年06月03日10时27分59秒
print('hello python')