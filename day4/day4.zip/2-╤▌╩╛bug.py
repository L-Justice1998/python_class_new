# 作者: 王道 龙哥
# 2022年06月03日11时00分01秒

def myfunc():
    print('hello')

myfunc()