# 作者: 王道 龙哥
# 2022年06月03日14时42分44秒
str1='hello'
list1=[1,2,3]
tuple1=(1,)
dict1={'name':'xiaoming'}
set1=set()
print(type(str1))
print(type(list1))
print(type(tuple1))
print(type(dict1))
print(type(set1))