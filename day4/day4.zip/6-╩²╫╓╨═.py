# 作者: 王道 龙哥
# 2022年06月03日11时57分09秒
f=1.23456789123456789
print(f)

print(True+False)

c=complex(3,4)
print("c is %d+%di" % (c.real,c.imag))