# 作者: 王道 龙哥
# 2022年06月03日16时43分03秒

def add100():
    # 计算 0 ~ 100 之间所有数字的累计求和结果
    # 0. 定义最终结果的变量
    result = 0

    # 1. 定义一个整数的变量记录循环的次数
    i = 0

    # 2. 开始循环
    while i <= 100:

        if i % 2 == 0:
            i += 1
            continue
        # 每一次循环，都让 result 这个变量和 i 这个计数器相加
        result += i

        # 处理计数器
        i += 1

    print("0~100之间的奇数求和结果 = %d" % result)

def print_star():
    # 1. 定义一个计数器变量，从数字1开始，循环会比较方便
    row = 1

    while row <= 5:
        print("*" * row)

        row += 1

print_star()