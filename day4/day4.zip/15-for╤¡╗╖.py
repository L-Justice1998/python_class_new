# 作者: 王道 龙哥
# 2022年06月03日16时53分23秒
a = [1, 2, 3]
for i in a:
    if i == 2:
        continue
    print(i)

print('-'*50)

total=0
for i in range(1,101):
    total+=i

print(total)

print('-'*50)
#必须是循环走到最后才会运行else
for i in range(10):
    if i == 15:
        print('i have 15')
        break
else:
    print("don't find")